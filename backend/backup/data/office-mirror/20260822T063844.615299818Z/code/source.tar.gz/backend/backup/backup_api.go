package backup

import (
	"encoding/json"
	"net/http"
	"strings"
)

type API struct {
	Service *Service
}

func NewAPI(service *Service) *API {
	return &API{
		Service: service,
	}
}

func (a *API) CreateBackup(
	w http.ResponseWriter,
	r *http.Request,
) {

	if r.Method != http.MethodPost {
		writeBackupError(
			w,
			http.StatusMethodNotAllowed,
			"method not allowed",
		)
		return
	}

	result, err := a.Service.Create()

	if err != nil {
		writeBackupError(
			w,
			http.StatusInternalServerError,
			err.Error(),
		)
		return
	}

	writeBackupJSON(
		w,
		http.StatusCreated,
		result,
	)
}

func (a *API) ListBackups(
	w http.ResponseWriter,
	r *http.Request,
) {

	if r.Method != http.MethodGet {
		writeBackupError(
			w,
			http.StatusMethodNotAllowed,
			"method not allowed",
		)
		return
	}

	result, err := a.Service.List()

	if err != nil {
		writeBackupError(
			w,
			http.StatusInternalServerError,
			err.Error(),
		)
		return
	}

	writeBackupJSON(
		w,
		http.StatusOK,
		map[string]any{
			"ok":      true,
			"backups": result,
		},
	)
}

func (a *API) VerifyBackup(
	w http.ResponseWriter,
	r *http.Request,
) {

	if r.Method != http.MethodGet {
		writeBackupError(
			w,
			http.StatusMethodNotAllowed,
			"method not allowed",
		)
		return
	}

	id := backupIDFromPath(
		r.URL.Path,
		"/api/superadmin/backups/",
		"/verify",
	)

	if id == "" {
		writeBackupError(
			w,
			http.StatusBadRequest,
			"backup id is required",
		)
		return
	}

	result, err := a.Service.Verify(id)

	if err != nil {
		writeBackupError(
			w,
			http.StatusConflict,
			err.Error(),
		)
		return
	}

	writeBackupJSON(
		w,
		http.StatusOK,
		map[string]any{
			"ok":     true,
			"backup": result,
		},
	)
}

func (a *API) RestoreBackup(
	w http.ResponseWriter,
	r *http.Request,
) {

	if r.Method != http.MethodPost {
		writeBackupError(
			w,
			http.StatusMethodNotAllowed,
			"method not allowed",
		)
		return
	}

	id := backupIDFromPath(
		r.URL.Path,
		"/api/superadmin/backups/",
		"/restore",
	)

	if id == "" {
		writeBackupError(
			w,
			http.StatusBadRequest,
			"backup id is required",
		)
		return
	}

	var payload struct {
		Confirm string `json:"confirm"`
		Target  string `json:"target"`
	}

	decoder := json.NewDecoder(
		r.Body,
	)

	if err := decoder.Decode(
		&payload,
	); err != nil {

		writeBackupError(
			w,
			http.StatusBadRequest,
			"invalid restore request",
		)
		return
	}

	result, err := a.Service.Restore(
		RestoreOptions{
			BackupID: id,
			Confirm:  payload.Confirm,
			Target:   payload.Target,
		},
	)

	if err != nil {

		status := http.StatusBadRequest

		if strings.Contains(
			err.Error(),
			"backup verification",
		) {
			status = http.StatusConflict
		}

		writeBackupError(
			w,
			status,
			err.Error(),
		)

		return
	}

	writeBackupJSON(
		w,
		http.StatusOK,
		map[string]any{
			"ok":      true,
			"restore": result,
		},
	)
}

func RegisterHTTPRoutes(
	mux *http.ServeMux,
	api *API,
) {

	mux.HandleFunc(
		"/api/superadmin/backups",
		func(
			w http.ResponseWriter,
			r *http.Request,
		) {

			switch r.Method {

			case http.MethodPost:
				api.CreateBackup(
					w,
					r,
				)

			case http.MethodGet:
				api.ListBackups(
					w,
					r,
				)

			default:
				writeBackupError(
					w,
					http.StatusMethodNotAllowed,
					"method not allowed",
				)
			}
		},
	)

	mux.HandleFunc(
		"/api/superadmin/backups/",
		func(
			w http.ResponseWriter,
			r *http.Request,
		) {

			if strings.HasSuffix(
				r.URL.Path,
				"/verify",
			) {

				api.VerifyBackup(
					w,
					r,
				)

				return
			}

			if strings.HasSuffix(
				r.URL.Path,
				"/restore",
			) {

				api.RestoreBackup(
					w,
					r,
				)

				return
			}

			writeBackupError(
				w,
				http.StatusNotFound,
				"backup route not found",
			)
		},
	)
}

func backupIDFromPath(
	path string,
	prefix string,
	suffix string,
) string {

	if !strings.HasPrefix(
		path,
		prefix,
	) {
		return ""
	}

	value := strings.TrimPrefix(
		path,
		prefix,
	)

	value = strings.TrimSuffix(
		value,
		suffix,
	)

	value = strings.Trim(
		value,
		"/",
	)

	if strings.Contains(
		value,
		"/",
	) {
		return ""
	}

	return value
}

func writeBackupJSON(
	w http.ResponseWriter,
	status int,
	value any,
) {

	w.Header().Set(
		"Content-Type",
		"application/json",
	)

	w.WriteHeader(status)

	_ = json.NewEncoder(
		w,
	).Encode(value)
}

func writeBackupError(
	w http.ResponseWriter,
	status int,
	message string,
) {

	writeBackupJSON(
		w,
		status,
		map[string]any{
			"ok":    false,
			"error": message,
		},
	)
}
