const fs = require('fs');
const path = require('path');

const basePath = path.join(process.cwd(), 'frontend', 'src', 'app', 'dashboard');
const rbacListDir = path.join(basePath, 'rbac-list');
const rbacDirPath = path.join(basePath, 'rbac');

// 1. Rollback old wrong folder
if (fs.existsSync(rbacListDir)) {
    fs.rmSync(rbacListDir, { recursive: true, force: true });
    console.log('✅ Removed wrong rbac-list folder');
}

// 2. Create correct rbac folder
if (!fs.existsSync(rbacDirPath)) { 
    fs.mkdirSync(rbacDirPath, { recursive: true }); 
    console.log('✅ Created correct directory: rbac'); 
}

// 3. rbac.component.ts
const tsContent = `import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LucideAngularModule } from 'lucide-angular';

export interface RbacRole { id: string; name: string; description: string; usersCount: number; isSystem: boolean; permissions: any; }
export interface RbacModuleDefinition { code: string; name: string; group: string; description: string; }

@Component({
  selector: 'app-dashboard-rbac',
  standalone: true,
  imports: [CommonModule, LucideAngularModule],
  templateUrl: './rbac.component.html',
  styles: [':host{display:block;width:100%;}']
})
export class DashboardRbacComponent {
  @Input() activeView = '';
  @Input() userRole = '';
  @Input() icons: any = {};
  @Output() navigate = new EventEmitter<string>();

  modules: RbacModuleDefinition[] = [
    { code: 'sys_dashboard', name: 'System Dashboard', group: 'Core', description: 'Access to main overview metrics' },
    { code: 'sys_users', name: 'User Management', group: 'Core', description: 'Create and manage system users' }
  ];

  roles: RbacRole[] = [
    { id: 'role_1', name: 'Super Admin', description: 'Unrestricted access.', usersCount: 2, isSystem: true, permissions: {} },
    { id: 'role_2', name: 'Client Admin', description: 'Business app access.', usersCount: 154, isSystem: true, permissions: {} }
  ];

  viewMode = 'list';
  selectedRole = null;
  editorDraft = null;

  openEditor(role) {
    if (role && role.isSystem) return;
    this.selectedRole = role || null;
    this.editorDraft = role ? JSON.parse(JSON.stringify(role)) : { id: 'new_'+Date.now(), name: 'New Custom Role', description: '', usersCount: 0, isSystem: false, permissions: {} };
    this.viewMode = 'editor';
  }

  closeEditor() { this.viewMode = 'list'; this.selectedRole = null; this.editorDraft = null; }
  saveRole() { this.closeEditor(); }
}
`;
fs.writeFileSync(path.join(rbacDirPath, 'rbac.component.ts'), tsContent);

// 4. rbac.component.html
const htmlContent = `<div *ngIf="activeView === 'rbac'" class="min-h-full">
  <div class="px-8 py-7 max-w-[98rem] mx-auto space-y-6">
    <div class="relative overflow-hidden rounded-[2rem] shadow-2xl" style="background:linear-gradient(135deg,#4f46e5 0%,#312e81 45%,#0f172a 100%)">
      <div class="relative px-7 py-7 flex flex-col lg:flex-row lg:items-center justify-between gap-5">
        <div>
          <h1 class="text-3xl font-black text-white uppercase tracking-tight leading-tight">Roles & Permissions<span class="text-indigo-300">.</span></h1>
          <p class="text-sm text-white/45 font-medium mt-2 max-w-2xl">Create custom roles and manage module entitlements.</p>
        </div>
        <div class="w-16 h-16 rounded-2xl bg-white/10 flex items-center justify-center ring-1 ring-white/15"><lucide-icon [name]="icons.ShieldCheck" class="w-8 h-8 text-white"></lucide-icon></div>
      </div>
    </div>
    
    <div *ngIf="viewMode === 'list'" class="animate-[fade-in_0.3s_ease-out]">
      <div class="flex items-center justify-between mb-4">
        <h2 class="text-lg font-black text-slate-900 uppercase tracking-tight">Active Roles</h2>
        <button (click)="openEditor(null)" class="flex items-center gap-2 px-5 py-2.5 bg-indigo-600 text-white rounded-xl text-xs font-black uppercase tracking-widest hover:bg-indigo-700 transition-all"><lucide-icon [name]="icons.Plus" class="w-4 h-4"></lucide-icon> New Custom Role</button>
      </div>
      <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
        <div *ngFor="let role of roles" class="bg-white rounded-[1.5rem] border border-slate-200 shadow-sm p-6 hover:shadow-xl transition-all group">
          <h3 class="text-lg font-black text-slate-900">{{ role.name }}</h3>
          <p class="text-sm font-medium text-slate-500 mt-2 h-10">{{ role.description }}</p>
          <div class="mt-4 pt-4 border-t border-slate-100 flex justify-between items-center">
            <span class="text-xs font-bold text-slate-400">{{ role.usersCount }} Users</span>
            <button *ngIf="!role.isSystem" (click)="openEditor(role)" class="text-[10px] font-black uppercase text-indigo-600 bg-indigo-50 px-3 py-1.5 rounded-lg">Edit</button>
          </div>
        </div>
      </div>
    </div>
    
    <div *ngIf="viewMode === 'editor'" class="bg-white rounded-[1.5rem] p-6 shadow-sm border border-slate-200">
      <div class="flex items-center justify-between mb-6">
        <h2 class="text-xl font-black text-slate-900">{{ selectedRole ? 'Edit Role' : 'Create Role' }}</h2>
        <button (click)="closeEditor()" class="text-slate-400 hover:text-slate-600"><lucide-icon [name]="icons.X" class="w-5 h-5"></lucide-icon></button>
      </div>
      <p class="text-sm text-slate-500 mb-6">Role editing interface will be connected to backend soon.</p>
      <button (click)="saveRole()" class="px-5 py-3 bg-indigo-600 text-white rounded-xl text-xs font-black uppercase tracking-widest">Close</button>
    </div>
  </div>
</div>`;
fs.writeFileSync(path.join(rbacDirPath, 'rbac.component.html'), htmlContent);
console.log('✅ Created rbac.component.html');

// 5. Update dashboard.component.ts
const tsFilePath = path.join(basePath, 'dashboard.component.ts');
if (fs.existsSync(tsFilePath)) {
    let dashTs = fs.readFileSync(tsFilePath, 'utf8');
    
    // Cleanup old imports if exist
    dashTs = dashTs.replace("import { DashboardRbacListComponent } from './rbac-list/rbac-list.component';\n", "");
    dashTs = dashTs.replace(", DashboardRbacListComponent]", "]");
    
    // Change rbac-list to rbac and change phase to LIVE in allCategories
    dashTs = dashTs.replace(/{ id: 'rbac', label: 'RBAC', icon: Shield, list: 'rbac-list', add: 'rbac-add', roles: \['super_admin'\], description: 'Role Based Access', color: 'bg-emerald-50 text-emerald-600', phase: 'FUTURE' }/g, 
                            `{ id: 'rbac', label: 'RBAC', icon: Shield, list: 'rbac', add: 'rbac-add', roles: ['super_admin'], description: 'Role Based Access', color: 'bg-emerald-50 text-emerald-600', phase: 'LIVE' }`);
                            
    // Add correct Import
    if (!dashTs.includes('DashboardRbacComponent')) {
        dashTs = dashTs.replace("import { DashboardSaasControlComponent } from './saas-control/saas-control.component';", 
                                "import { DashboardSaasControlComponent } from './saas-control/saas-control.component';\nimport { DashboardRbacComponent } from './rbac/rbac.component';");
        dashTs = dashTs.replace("DashboardSaasControlComponent]", "DashboardSaasControlComponent, DashboardRbacComponent]");
    }
    fs.writeFileSync(tsFilePath, dashTs);
    console.log('✅ Updated dashboard.component.ts');
}

// 6. Update overview.component.html (Unlock Overview Card)
const overviewPath = path.join(basePath, 'overview', 'overview.component.html');
if (fs.existsSync(overviewPath)) {
    let overviewHtml = fs.readFileSync(overviewPath, 'utf8');
    overviewHtml = overviewHtml.replace(/{label:'RBAC',desc:'Access control',icon:icons.Shield,view:'rbac-list',phase:'FUTURE'}/g, 
                                        `{label:'RBAC',desc:'Access control',icon:icons.Shield,view:'rbac',phase:'LIVE'}`);
    fs.writeFileSync(overviewPath, overviewHtml);
    console.log('✅ Updated overview.component.html');
}

// 7. Update dashboard.component.html
const htmlFilePath = path.join(basePath, 'dashboard.component.html');
if (fs.existsSync(htmlFilePath)) {
    let dashHtml = fs.readFileSync(htmlFilePath, 'utf8');
    
    // Remove old host if exists
    const badCode = `      <!-- SCS_DASHBOARD_RBAC_LIST_HOST_V1 -->
      <app-dashboard-rbac-list
        *ngIf="activeView === 'rbac-list'"
        [activeView]="activeView"
        [userRole]="userRole"
        [icons]="icons"
        (navigate)="navigateTo($event)">
      </app-dashboard-rbac-list>\n\n`;
    dashHtml = dashHtml.replace(badCode, '');
    
    // Add new host
    if (!dashHtml.includes('<app-dashboard-rbac')) {
        dashHtml = dashHtml.replace('      <!-- SCS_SUPERADMIN_PLATFORM_EXPANSION_PAGES_END -->', 
`      <!-- SCS_DASHBOARD_RBAC_HOST_V1 -->
      <app-dashboard-rbac 
        *ngIf="activeView === 'rbac'" 
        [activeView]="activeView" 
        [userRole]="userRole" 
        [icons]="icons" 
        (navigate)="navigateTo($event)">
      </app-dashboard-rbac>
      <!-- SCS_SUPERADMIN_PLATFORM_EXPANSION_PAGES_END -->`);
        fs.writeFileSync(htmlFilePath, dashHtml);
        console.log('✅ Updated dashboard.component.html');
    }
}

console.log('🎉 Fix complete! RBAC is now LIVE in dashboard/rbac. Please restart your dev server.');
