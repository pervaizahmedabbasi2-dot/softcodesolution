import { Component, OnInit } from '@angular/core';

import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { DashboardApiService } from '../services/dashboard-api.service';

interface BackupRecord {
  id?: string;
  created_at?: string;
  postgres?: boolean;
  sqlite?: boolean;
  postgres_sha256?: string;
  sqlite_sha256?: string;
  size_bytes?: number;
  status?: string;
  office_mirror_path?: string;
  office_mirror_sha256?: string;
  office_mirror_verified?: boolean;
}

@Component({
  selector: 'app-dashboard-backup-manager',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './backup-manager.component.html',
  styleUrl: './backup-manager.component.css',
})
export class BackupManagerComponent implements OnInit {
  backups: BackupRecord[] = [];

  get latestBackup(): BackupRecord | null {
    if (!this.backups.length) {
      return null;
    }

    return [...this.backups].sort((a, b) => {
      const left =
        new Date(a.created_at || 0).getTime();

      const right =
        new Date(b.created_at || 0).getTime();

      return right - left;
    })[0] || null;
  }

  loading = false;
  creating = false;
  verifyingId: string | null = null;
  restoringId: string | null = null;

  errorMessage = '';
  successMessage = '';

  selectedBackup: BackupRecord | null = null;

  restoreTarget: 'local' | 'postgres' | 'both' = 'both';

  showRestoreConfirm = false;

  constructor(private readonly api: DashboardApiService) {}

  async ngOnInit(): Promise<void> {
    await this.loadBackups();
  }

  async loadBackups(): Promise<void> {
    this.loading = true;
    this.errorMessage = '';

    try {
      this.backups = await this.api.listBackups();
    } catch (error) {
      this.errorMessage = String(error);
    } finally {
      this.loading = false;
    }
  }

  async createBackup(): Promise<void> {
    if (this.creating) {
      return;
    }

    this.creating = true;
    this.errorMessage = '';
    this.successMessage = '';

    try {
      const result = await this.api.createBackup();

      if (result?.ok === false) {
        this.errorMessage = result?.message || 'Backup creation failed.';

        return;
      }

      this.successMessage = 'Backup created successfully.';

      await this.loadBackups();
    } catch (error) {
      this.errorMessage = String(error);
    } finally {
      this.creating = false;
    }
  }

  async verifyBackup(backup: BackupRecord): Promise<void> {
    const id = backup.id;

    if (!id || this.verifyingId) {
      return;
    }

    this.verifyingId = id;
    this.errorMessage = '';
    this.successMessage = '';

    try {
      const result = await this.api.verifyBackup(id);

      if (result?.ok === false) {
        this.errorMessage = result?.message || 'Backup verification failed.';

        return;
      }

      this.successMessage = 'Backup SHA-256 verification passed.';

      await this.loadBackups();
    } catch (error) {
      this.errorMessage = String(error);
    } finally {
      this.verifyingId = null;
    }
  }

  openRestore(backup: BackupRecord): void {
    if (!backup.id) {
      return;
    }

    this.selectedBackup = backup;
    this.restoreTarget = 'both';
    this.showRestoreConfirm = true;
    this.errorMessage = '';
    this.successMessage = '';
  }

  cancelRestore(): void {
    this.showRestoreConfirm = false;
    this.selectedBackup = null;
  }

  async confirmRestore(): Promise<void> {
    const backup = this.selectedBackup;

    if (!backup?.id || this.restoringId) {
      return;
    }

    this.restoringId = backup.id;

    this.errorMessage = '';
    this.successMessage = '';

    try {
      const result = await this.api.restoreBackup(backup.id, this.restoreTarget);

      if (result?.ok === false) {
        const detail =
          result?.message ||
          result?.error ||
          result?.detail ||
          result?.data?.message ||
          JSON.stringify(result);

        console.error(
          '❌ Backup restore failed:',
          result,
        );

        this.errorMessage =
          String(detail || 'Restore failed.');

        return;
      }

      this.successMessage = 'Restore completed successfully.';

      this.showRestoreConfirm = false;
      this.selectedBackup = null;

      await this.loadBackups();
    } catch (error) {
      this.errorMessage = String(error);
    } finally {
      this.restoringId = null;
    }
  }

  formatBytes(value: number | undefined): string {
    if (!value) {
      return '0 B';
    }

    const units = ['B', 'KB', 'MB', 'GB', 'TB'];

    let size = value;
    let index = 0;

    while (size >= 1024 && index < units.length - 1) {
      size /= 1024;
      index++;
    }

    return size.toFixed(index === 0 ? 0 : 2) + ' ' + units[index];
  }
}
