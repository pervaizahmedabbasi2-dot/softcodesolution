import { Component, OnInit, ChangeDetectorRef, inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { NotificationService } from '../services/notification.service';

function sanitizeInput(value: string): string {
  if (!value) return '';
  return value
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
    .replace(/on\w+="[^"]*"/gi, '')
    .replace(/javascript:/gi, '')
    .replace(/vbscript:/gi, '')
    .trim();
}

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule],
  templateUrl: './login.component.html'
})
export class LoginComponent implements OnInit {
  private fb = inject(FormBuilder);
  private router = inject(Router);
  private cdr = inject(ChangeDetectorRef);
  private notification = inject(NotificationService);

  loginForm!: FormGroup;
  isLoading = false;
  showSuccessPopup = false;
  showLoginError = false;
  isPasswordVisible = false;
  rememberMe = false;

  showForgotPopup = false;
  showForgotSuccess = false;
  forgotEmail = '';
  forgotEmailError = false;
  forgotLoading = false;

  private redirectPath = '/dashboard';

  ngOnInit(): void {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(8)]]
    });

    const savedEmail = localStorage.getItem('scs_remembered_email');
    if (savedEmail) {
      this.loginForm.get('email')?.setValue(savedEmail);
      this.rememberMe = true;
    }
  }

  togglePassword(): void {
    this.isPasswordVisible = !this.isPasswordVisible;
  }

  toggleRememberMe(): void {
    this.rememberMe = !this.rememberMe;
  }

  onForgotPassword(): void {
    this.forgotEmail = this.loginForm.value.email || '';
    this.forgotEmailError = false;
    this.showForgotPopup = true;
    this.cdr.detectChanges();
  }

  closeForgotPopup(): void {
    this.showForgotPopup = false;
    this.forgotEmailError = false;
  }

  async submitForgotPassword(): Promise<void> {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const cleanEmail = sanitizeInput(this.forgotEmail);

    if (!cleanEmail || !emailRegex.test(cleanEmail)) {
      this.forgotEmailError = true;
      return;
    }

    this.forgotLoading = true;
    this.cdr.detectChanges();

    setTimeout(() => {
      this.forgotLoading = false;
      this.showForgotPopup = false;
      this.showForgotSuccess = true;
      this.cdr.detectChanges();
    }, 1200);
  }

  finishForgot(): void {
    this.showForgotSuccess = false;
    this.forgotEmail = '';
  }

  async onSubmit(): Promise<void> {
    this.showLoginError = false;

    if (this.loginForm.invalid) {
      this.loginForm.markAllAsTouched();
      return;
    }

    this.isLoading = true;
    this.cdr.detectChanges();

    const sanitizedEmail = sanitizeInput(this.loginForm.value.email || '').toLowerCase();
    const password = this.loginForm.value.password || '';

    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Request-ID': `login-${Date.now()}`
        },
        body: JSON.stringify({
          email: sanitizedEmail,
          password,
          remember_me: this.rememberMe
        }),
        credentials: 'include',
        cache: 'no-store'
      });

      const result = await response.json().catch(() => ({
        ok: false,
        message: 'Invalid server response'
      }));

      if (response.ok && result.ok) {
        if (this.rememberMe) {
          localStorage.setItem('scs_remembered_email', sanitizedEmail);
        } else {
          localStorage.removeItem('scs_remembered_email');
        }

        localStorage.removeItem('auth_token');
        localStorage.removeItem('user_data');
        localStorage.removeItem('scs_tenant_id');

        this.redirectPath = typeof result.redirect === 'string' ? result.redirect : '/dashboard';
        this.showSuccessPopup = true;
      } else {
        this.showLoginError = true;
        this.notification.error(result.message || 'Invalid email or password');
      }
    } catch (error) {
      console.error('Login failed:', error);
      this.showLoginError = true;
      this.notification.error('Network error. Please check connection.');
    } finally {
      this.isLoading = false;
      this.loginForm.get('password')?.setValue('');
      this.cdr.detectChanges();
    }
  }

  finishLogin(): void {
    this.showSuccessPopup = false;
    this.router.navigateByUrl(this.redirectPath || '/dashboard');
  }

  goToRegister(): void {
    this.router.navigate(['/register']);
  }
}
