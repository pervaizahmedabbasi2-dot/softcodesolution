const fs = require('fs');
const path = require('path');

const basePath = path.join(process.cwd(), 'frontend', 'src', 'app', 'dashboard');
const rbacDirPath = path.join(basePath, 'rbac-list');

// 1. Create directory if not exists
if (!fs.existsSync(rbacDirPath)) {
    fs.mkdirSync(rbacDirPath, { recursive: true });
    console.log('✅ Created directory: rbac-list');
}

// 2. rbac-list.component.ts content
const tsContent = `import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LucideAngularModule } from 'lucide-angular';

export interface RbacRole { id: string; name: string; description: string; usersCount: number; isSystem: boolean; permissions: RbacPermissionMap; }
export interface RbacPermissionMap { [moduleCode: string]: { read: boolean; write: boolean; delete: boolean; }; }
export interface RbacModuleDefinition { code: string; name: string; group: string; description: string; }

@Component({
  selector: 'app-dashboard-rbac-list',
  standalone: true,
  imports: [CommonModule, LucideAngularModule],
  templateUrl: './rbac-list.component.html',
  styles: [':host{display:block;width:100%;}']
})
export class DashboardRbacListComponent {
  @Input() activeView = '';
  @Input() userRole = '';
  @Input() icons: any = {};
  @Output() navigate = new EventEmitter<string>();

  modules: RbacModuleDefinition[] = [
    { code: 'sys_dashboard', name: 'System Dashboard', group: 'Core', description: 'Access to main overview metrics' },
    { code: 'sys_users', name: 'User Management', group: 'Core', description: 'Create and manage system users' },
    { code: 'saas_billing', name: 'Billing & Plans', group: 'SaaS', description: 'Manage subscriptions and invoices' },
    { code: 'biz_pos', name: 'Point of Sale', group: 'Business Apps', description: 'Access to POS terminal' },
    { code: 'biz_inventory', name: 'Inventory Control', group: 'Business Apps', description: 'Manage products and stock' },
    { code: 'biz_reports', name: 'Financial Reports', group: 'Business Apps', description: 'View sensitive financial data' }
  ];

  roles: RbacRole[] = [
    {
      id: 'role_1', name: 'Super Admin', description: 'Unrestricted access to all platform features and settings.', usersCount: 2, isSystem: true,
      permissions: {
        'sys_dashboard': { read: true, write: true, delete: true }, 'sys_users': { read: true, write: true, delete: true },
        'saas_billing': { read: true, write: true, delete: true }, 'biz_pos': { read: true, write: true, delete: true },
        'biz_inventory': { read: true, write: true, delete: true }, 'biz_reports': { read: true, write: true, delete: true },
      }
    },
    {
      id: 'role_2', name: 'Client Admin', description: 'Full access to business apps, limited SaaS control.', usersCount: 154, isSystem: true,
      permissions: {
        'sys_dashboard': { read: true, write: false, delete: false }, 'sys_users': { read: true, write: true, delete: false },
        'saas_billing': { read: true, write: false, delete: false }, 'biz_pos': { read: true, write: true, delete: true },
        'biz_inventory': { read: true, write: true, delete: true }, 'biz_reports': { read: true, write: true, delete: false },
      }
    }
  ];

  viewMode = 'list';
  selectedRole = null;
  editorDraft = null;

  navigateTo(view) { this.navigate.emit(view); }

  openEditor(role) {
    if (role) {
      if (role.isSystem) return; 
      this.selectedRole = role;
      this.editorDraft = JSON.parse(JSON.stringify(role));
    } else {
      this.selectedRole = null;
      this.editorDraft = { id: 'new_' + Date.now(), name: 'New Custom Role', description: 'Describe what this role can do...', usersCount: 0, isSystem: false, permissions: {} };
      for (const mod of this.modules) { this.editorDraft.permissions[mod.code] = { read: false, write: false, delete: false }; }
    }
    this.viewMode = 'editor';
  }

  closeEditor() { this.viewMode = 'list'; this.selectedRole = null; this.editorDraft = null; }

  togglePermission(modCode, type) {
    if (!this.editorDraft) return;
    if (!this.editorDraft.permissions[modCode]) { this.editorDraft.permissions[modCode] = { read: false, write: false, delete: false }; }
    this.editorDraft.permissions[modCode][type] = !this.editorDraft.permissions[modCode][type];
    if ((type === 'write' || type === 'delete') && this.editorDraft.permissions[modCode][type]) { this.editorDraft.permissions[modCode].read = true; }
    if (type === 'read' && !this.editorDraft.permissions[modCode].read) { this.editorDraft.permissions[modCode].write = false; this.editorDraft.permissions[modCode].delete = false; }
  }

  saveRole() {
    if (!this.editorDraft) return;
    if (this.selectedRole) {
      const idx = this.roles.findIndex(r => r.id === this.editorDraft.id);
      if (idx !== -1) this.roles[idx] = JSON.parse(JSON.stringify(this.editorDraft));
    } else { this.roles.push(JSON.parse(JSON.stringify(this.editorDraft))); }
    this.closeEditor();
  }

  getModulesByGroup() {
    const groups = {};
    for (const m of this.modules) { if (!groups[m.group]) groups[m.group] = []; groups[m.group].push(m); }
    return Object.keys(groups).map(g => ({ group: g, modules: groups[g] }));
  }
}
\`;
fs.writeFileSync(path.join(rbacDirPath, 'rbac-list.component.ts'), tsContent);
console.log('✅ Created rbac-list.component.ts');

// 3. rbac-list.component.html content
const htmlContent = \`<!-- RBAC Component UI -->
<div *ngIf="activeView === 'rbac-list'" class="min-h-full">
  <div class="px-8 py-7 max-w-[98rem] mx-auto space-y-6">
    <!-- Header -->
    <div class="relative overflow-hidden rounded-[2rem] shadow-2xl" style="background:linear-gradient(135deg,#4f46e5 0%,#312e81 45%,#0f172a 100%)">
      <div class="absolute inset-0 opacity-10" style="background-image:radial-gradient(circle,#fff 1px,transparent 1px);background-size:28px 28px"></div>
      <div class="relative px-7 py-7 flex flex-col lg:flex-row lg:items-center justify-between gap-5">
        <div>
          <div class="flex flex-wrap items-center gap-2 mb-3"><span class="px-3 py-1.5 rounded-full text-[10px] font-black uppercase tracking-[3px] text-white/80" style="background:rgba(255,255,255,0.12);border:1px solid rgba(255,255,255,0.18)">Access Control</span></div>
          <h1 class="text-3xl font-black text-white uppercase tracking-tight leading-tight">Roles & Permissions<span class="text-indigo-300">.</span></h1>
          <p class="text-sm text-white/45 font-medium mt-2 max-w-2xl">Create custom roles, manage module entitlements, and define granular access limits across the platform.</p>
        </div>
        <div class="w-16 h-16 rounded-2xl bg-white/10 flex items-center justify-center ring-1 ring-white/15"><lucide-icon [name]="icons.ShieldCheck" class="w-8 h-8 text-white"></lucide-icon></div>
      </div>
    </div>
    <!-- ROLE LIST VIEW -->
    <div *ngIf="viewMode === 'list'" class="animate-[fade-in_0.3s_ease-out]">
      <div class="flex items-center justify-between mb-4">
        <h2 class="text-lg font-black text-slate-900 uppercase tracking-tight">Active Roles</h2>
        <button (click)="openEditor()" class="flex items-center gap-2 px-5 py-2.5 bg-indigo-600 text-white rounded-xl text-xs font-black uppercase tracking-widest hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-500/30"><lucide-icon [name]="icons.Plus" class="w-4 h-4"></lucide-icon> New Custom Role</button>
      </div>
      <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
        <div *ngFor="let role of roles" class="bg-white rounded-[1.5rem] border border-slate-200 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300 overflow-hidden group">
          <div class="p-6">
            <div class="flex items-start justify-between mb-4">
              <div class="flex items-center gap-3">
                <div class="w-12 h-12 rounded-xl flex items-center justify-center" [ngClass]="role.isSystem ? 'bg-indigo-50' : 'bg-emerald-50'"><lucide-icon [name]="role.isSystem ? icons.Server : icons.User" class="w-6 h-6" [ngClass]="role.isSystem ? 'text-indigo-600' : 'text-emerald-600'"></lucide-icon></div>
                <div>
                  <h3 class="text-lg font-black text-slate-900 leading-tight">{{ role.name }}</h3>
                  <div class="flex items-center gap-2 mt-1"><span class="px-2 py-0.5 rounded bg-slate-100 text-[9px] font-black uppercase tracking-widest" [ngClass]="role.isSystem ? 'text-indigo-500' : 'text-emerald-500'">{{ role.isSystem ? 'System Role' : 'Custom Role' }}</span></div>
                </div>
              </div>
            </div>
            <p class="text-sm font-medium text-slate-500 mb-5 leading-relaxed h-10 line-clamp-2">{{ role.description }}</p>
            <div class="flex items-center justify-between pt-4 border-t border-slate-100">
              <div class="flex items-center gap-1.5 text-slate-400"><lucide-icon [name]="icons.Users" class="w-4 h-4"></lucide-icon><span class="text-xs font-bold">{{ role.usersCount }} Users</span></div>
              <button *ngIf="!role.isSystem" (click)="openEditor(role)" class="text-[10px] font-black uppercase tracking-widest text-indigo-600 hover:text-indigo-800 bg-indigo-50 px-3 py-1.5 rounded-lg transition-colors">Edit Access</button>
              <button *ngIf="role.isSystem" class="text-[10px] font-black uppercase tracking-widest text-slate-400 cursor-not-allowed bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200">Locked</button>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- ROLE EDITOR (PERMISSION MATRIX) -->
    <div *ngIf="viewMode === 'editor'" class="animate-[fade-in_0.3s_ease-out]">
      <div class="flex flex-col xl:flex-row gap-6">
        <div class="xl:w-1/3 space-y-5">
          <div class="bg-white rounded-[1.5rem] p-6 border border-slate-200 shadow-sm">
            <div class="flex items-center gap-3 mb-6"><button (click)="closeEditor()" class="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center hover:bg-slate-200 transition-colors"><lucide-icon [name]="icons.X" class="w-4 h-4 text-slate-600"></lucide-icon></button><h2 class="text-xl font-black text-slate-900 tracking-tight">{{ selectedRole ? 'Edit Role' : 'Create New Role' }}</h2></div>
            <div class="space-y-4">
              <div><label class="block text-[10px] font-black uppercase tracking-widest text-slate-400 mb-1.5">Role Name</label><input type="text" [(ngModel)]="editorDraft!.name" class="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm font-bold text-slate-900 focus:outline-none focus:border-indigo-500"></div>
              <div><label class="block text-[10px] font-black uppercase tracking-widest text-slate-400 mb-1.5">Description</label><textarea [(ngModel)]="editorDraft!.description" rows="3" class="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm font-bold text-slate-900 focus:outline-none focus:border-indigo-500 resize-none"></textarea></div>
            </div>
            <button (click)="saveRole()" class="w-full mt-6 py-4 rounded-xl text-white text-[11px] font-black uppercase tracking-widest shadow-lg" style="background:linear-gradient(135deg,#4f46e5,#3730a3)">Save Role & Permissions</button>
          </div>
        </div>
        <div class="xl:w-2/3 bg-white rounded-[2rem] border border-slate-200 shadow-sm overflow-hidden">
          <div class="px-6 py-5 border-b border-slate-100 bg-slate-50 flex items-center justify-between"><h3 class="text-sm font-black text-slate-900 uppercase tracking-tight">Module Entitlements Matrix</h3></div>
          <div class="p-2 space-y-2">
            <ng-container *ngFor="let groupData of getModulesByGroup()">
              <div class="px-4 py-2 mt-4 first:mt-0"><p class="text-[10px] font-black uppercase tracking-[0.25em] text-indigo-500">{{ groupData.group }}</p></div>
              <div *ngFor="let mod of groupData.modules" class="mx-2 p-4 rounded-xl border border-slate-100 hover:border-indigo-100 hover:bg-indigo-50/30 transition-colors">
                <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div><p class="text-sm font-black text-slate-900">{{ mod.name }}</p><p class="text-[10px] font-bold text-slate-400 mt-0.5">{{ mod.description }}</p></div>
                  <div class="flex items-center gap-3">
                    <button (click)="togglePermission(mod.code, 'read')" class="flex flex-col items-center gap-1.5"><div class="w-12 h-6 rounded-full p-0.5 transition-colors relative" [ngClass]="editorDraft!.permissions[mod.code]?.read ? 'bg-indigo-500' : 'bg-slate-200'"><div class="w-5 h-5 rounded-full bg-white shadow-sm transition-transform" [ngClass]="editorDraft!.permissions[mod.code]?.read ? 'translate-x-6' : 'translate-x-0'"></div></div><span class="text-[9px] font-black uppercase tracking-widest" [ngClass]="editorDraft!.permissions[mod.code]?.read ? 'text-indigo-600' : 'text-slate-400'">Read</span></button>
                    <div class="w-px h-8 bg-slate-200"></div>
                    <button (click)="togglePermission(mod.code, 'write')" class="flex flex-col items-center gap-1.5"><div class="w-12 h-6 rounded-full p-0.5 transition-colors relative" [ngClass]="editorDraft!.permissions[mod.code]?.write ? 'bg-emerald-500' : 'bg-slate-200'"><div class="w-5 h-5 rounded-full bg-white shadow-sm transition-transform" [ngClass]="editorDraft!.permissions[mod.code]?.write ? 'translate-x-6' : 'translate-x-0'"></div></div><span class="text-[9px] font-black uppercase tracking-widest" [ngClass]="editorDraft!.permissions[mod.code]?.write ? 'text-emerald-600' : 'text-slate-400'">Write</span></button>
                    <div class="w-px h-8 bg-slate-200"></div>
                    <button (click)="togglePermission(mod.code, 'delete')" class="flex flex-col items-center gap-1.5"><div class="w-12 h-6 rounded-full p-0.5 transition-colors relative" [ngClass]="editorDraft!.permissions[mod.code]?.delete ? 'bg-rose-500' : 'bg-slate-200'"><div class="w-5 h-5 rounded-full bg-white shadow-sm transition-transform" [ngClass]="editorDraft!.permissions[mod.code]?.delete ? 'translate-x-6' : 'translate-x-0'"></div></div><span class="text-[9px] font-black uppercase tracking-widest" [ngClass]="editorDraft!.permissions[mod.code]?.delete ? 'text-rose-600' : 'text-slate-400'">Delete</span></button>
                  </div>
                </div>
              </div>
            </ng-container>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>\`
fs.writeFileSync(path.join(rbacDirPath, 'rbac-list.component.html'), htmlContent);
console.log('✅ Created rbac-list.component.html');

// 4. Update dashboard.component.ts
const tsFilePath = path.join(basePath, 'dashboard.component.ts');
if (fs.existsSync(tsFilePath)) {
    let dashboardTs = fs.readFileSync(tsFilePath, 'utf8');
    if (!dashboardTs.includes('DashboardRbacListComponent')) {
        dashboardTs = dashboardTs.replace(
            "import { DashboardSaasControlComponent } from './saas-control/saas-control.component';",
            "import { DashboardSaasControlComponent } from './saas-control/saas-control.component';\\nimport { DashboardRbacListComponent } from './rbac-list/rbac-list.component';"
        );
        dashboardTs = dashboardTs.replace(
            "DashboardSaasControlComponent]",
            "DashboardSaasControlComponent, DashboardRbacListComponent]"
        );
        fs.writeFileSync(tsFilePath, dashboardTs);
        console.log('✅ Updated dashboard.component.ts');
    } else {
        console.log('⚠️ dashboard.component.ts already contains DashboardRbacListComponent');
    }
}

// 5. Update dashboard.component.html
const htmlFilePath = path.join(basePath, 'dashboard.component.html');
if (fs.existsSync(htmlFilePath)) {
    let dashboardHtml = fs.readFileSync(htmlFilePath, 'utf8');
    if (!dashboardHtml.includes('<app-dashboard-rbac-list')) {
        const replacement = \`      <!-- SCS_DASHBOARD_RBAC_LIST_HOST_V1 -->
      <app-dashboard-rbac-list
        *ngIf="activeView === 'rbac-list'"
        [activeView]="activeView"
        [userRole]="userRole"
        [icons]="icons"
        (navigate)="navigateTo($event)">
      </app-dashboard-rbac-list>

      <!-- SCS_SUPERADMIN_PLATFORM_EXPANSION_PAGES_END -->\`;
        dashboardHtml = dashboardHtml.replace('      <!-- SCS_SUPERADMIN_PLATFORM_EXPANSION_PAGES_END -->', replacement);
        fs.writeFileSync(htmlFilePath, dashboardHtml);
        console.log('✅ Updated dashboard.component.html');
    } else {
        console.log('⚠️ dashboard.component.html already contains <app-dashboard-rbac-list');
    }
}
console.log('🎉 Patch complete! Now run \`ng serve\` or \`ng build\` to test.');
