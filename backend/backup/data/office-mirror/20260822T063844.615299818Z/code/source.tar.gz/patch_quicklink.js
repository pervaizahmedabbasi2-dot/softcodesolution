const fs = require('fs');
const path = require('path');

const dashTs = path.join(process.cwd(), 'frontend', 'src', 'app', 'dashboard', 'dashboard.component.ts');

if (fs.existsSync(dashTs)) {
    let code = fs.readFileSync(dashTs, 'utf8');
    
    // Fix quick link to point to 'rbac' instead of 'rbac-list'
    code = code.replace(
        "{ title: 'RBAC', view: 'rbac-list' }", 
        "{ title: 'RBAC', view: 'rbac' }"
    );
    
    fs.writeFileSync(dashTs, code);
    console.log('✅ Quick Link Fixed! RBAC ab sahi page par point kar raha ہے۔');
    console.log('🔄 Angular aapka page auto-refresh kar dega.');
} else {
    console.log('❌ Error: dashboard.component.ts file nahi mili.');
}
