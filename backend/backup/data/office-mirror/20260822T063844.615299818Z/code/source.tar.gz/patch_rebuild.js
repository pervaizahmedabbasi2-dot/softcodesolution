const fs = require('fs');
const path = require('path');

const mainTs = path.join(process.cwd(), 'frontend', 'src', 'main.ts');

if (fs.existsSync(mainTs)) {
    const now = new Date();
    // Yeh line file ki time update karegi, jis se Angular khud rebuild shuru kar dega
    fs.utimesSync(mainTs, now, now);
    
    console.log('🔄 Frontend files ko touch kar diya gaya hai.');
    console.log('⏳ Ab Angular ka server khud ba khud REBUILD ho raha hoga...');
    console.log('✅ Jab aapke terminal mein dobara "Application bundle generation complete" aa jaye, toh browser ko F5 se refresh kijiye!');
} else {
    console.log('❌ Error: main.ts file nahi mili.');
}
