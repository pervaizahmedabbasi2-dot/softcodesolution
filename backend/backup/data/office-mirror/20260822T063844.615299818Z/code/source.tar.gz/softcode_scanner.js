const fs = require('fs');
const path = require('path');

const targetFunctions = [
    'handleSuperadminSubscriptionSave',
    'recalculateTenantSubscriptionAmount',
    'loadTenantSubscriptionSummary'
];

function findGoFiles(dir, fileList = []) {
    const files = fs.readdirSync(dir);
    for (const file of files) {
        if (file === 'node_modules' || file === '.git' || file === 'frontend' || file === 'dist') continue;
        
        const filePath = path.join(dir, file);
        if (fs.statSync(filePath).isDirectory()) {
            findGoFiles(filePath, fileList);
        } else if (file.endsWith('.go')) {
            fileList.push(filePath);
        }
    }
    return fileList;
}

function extractFunctionBody(lines, startIndex) {
    let braceCount = 0;
    let funcBody = [];
    let started = false;

    for (let i = startIndex; i < lines.length; i++) {
        const line = lines[i];
        funcBody.push(line);
        
        for (let char of line) {
            if (char === '{') { braceCount++; started = true; } 
            else if (char === '}') { braceCount--; }
        }
        
        if (started && braceCount === 0) { break; }
    }
    return funcBody.join('\n');
}

function scanProject() {
    console.log("========================================================");
    console.log("SOFTCODESOLUTION HUB (V16.0) - ARCHITECTURE SCANNER");
    console.log("========================================================\n");
    
    const goFiles = findGoFiles(process.cwd());
    const report = { duplicates: {}, callers: [] };
    
    targetFunctions.forEach(fn => report.duplicates[fn] = []);

    for (const file of goFiles) {
        const content = fs.readFileSync(file, 'utf-8');
        const lines = content.split('\n');
        
        targetFunctions.forEach(fn => {
            const funcRegex = new RegExp(`^func\\s+(?:\\([^)]+\\)\\s+)?${fn}\\s*\\(`, 'm');
            for (let i = 0; i < lines.length; i++) {
                if (lines[i].match(funcRegex)) {
                    const body = extractFunctionBody(lines, i);
                    report.duplicates[fn].push({ file: path.basename(file), line: i + 1, code: body });
                }
            }
        });

        targetFunctions.forEach(fn => {
            for (let i = 0; i < lines.length; i++) {
                const line = lines[i];
                if (line.includes(fn) && !line.match(new RegExp(`^func\\s+(?:\\([^)]+\\)\\s+)?${fn}\\s*\\(`)) && !line.trim().startsWith('//')) {
                    report.callers.push({ file: path.basename(file), line: i + 1, code: line.trim() });
                }
            }
        });
    }

    console.log("[1] DUPLICATE FUNCTION IMPLEMENTATIONS EXTRACTED:");
    targetFunctions.forEach(fn => {
        console.log(`\n>>> FUNCTION: ${fn} <<<`);
        report.duplicates[fn].forEach(dup => {
            console.log(`\n--- Found in: ${dup.file} (Line ${dup.line}) ---`);
            console.log(dup.code);
        });
    });

    console.log("\n========================================================");
    console.log("[2] ALL FUNCTION CALLERS IN THE PROJECT:");
    report.callers.forEach(caller => {
        console.log(`File: ${caller.file} | Line: ${caller.line} | Code: ${caller.code}`);
    });
}

scanProject();
